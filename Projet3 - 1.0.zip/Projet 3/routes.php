<?php
    // A creer pour chaques pages
    $_pages = [
        'connection' => ['layout' => 'auth', 'data' => ['title' => 'Connection']],
        'inscription' => ['layout' => 'auth', 'data' => ['title' => 'Inscription']],
        'a' => ['layout' => 'app', 'data' => ['title' => 'AAAAAA']],
        'b' => ['layout' => 'app', 'data' => ['title' => 'BBBBBBB']],
    ];

    $_controllers = [
        'connection' => 'POST',
    ];

    $test = 100;


    // Fonction a utiliser simplement pour aficher une page depuis un controller en php
    function includePage($page)
    {
        global $_pages;

        $pagePath = "pages/$page.php";


        if(file_exists($pagePath))
        {
            $layout = $_pages[$page]['layout'];
            $data = $_pages[$page]['data'];

            makePage($layout, $page, $data);
        }
        else
        {
            http_response_code(404);
        }

        die;
    }

    // NE PAS UTILISER

    function includeController($ctrl)
    {
        global $_controllers;

        $ctrlPath = "controllers/$ctrl.php";


        if(file_exists($ctrlPath))
        {
            include($ctrlPath);
        }
        else
        {
            http_response_code(404);
        }

        die;
    }

    function makePage($layout, $_page, $_data)
    {
        include("pages/layout/$layout.php");
    }

    function pageExist($page)
    {
        global $_pages;

        return isset($_pages[$page]);
    }

    function controllerExist($ctrl)
    {
        global $_controllers;

        return isset($_controllers[$ctrl]);
    }