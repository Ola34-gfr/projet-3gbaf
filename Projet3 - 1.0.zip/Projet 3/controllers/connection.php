<?php
    $username = $_POST['username'];

    if($username == 'Ola')
    {
        includePage('a');
    }
    else
    {
        includePage('connection');
    }
    