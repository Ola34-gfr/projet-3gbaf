<form enctype="multipart/form-data" method="POST" action="verification_d'inscription.php" > 

	<p>Saisis ton UserName et répond à la question secrète ci-dessous pour pour créer un nouveau Password :<p>


	<label><b>UserName</b></label>
	<input type="text" placeholder="Entrer le nom d'utilisateur" name="username" required>


	<label><b>Réponse à la question secrète</b></label>
	<input type="text" placeholder="Entrer la réponse" name="reponse" required>

	<input  type="submit" id='submit' value="Continuer" />  

</form>