<!DOCTYPE html>
<html>
    <head>
        <!-- importer le fichier de style -->
        <link rel="stylesheet" href="pages/layout/style.css" media="screen" type="text/css" />

        <title><?php echo $_data['title']?></title>
    </head>
    <body> 
    <header>
			<img src="photogbaf-ConvertImage.png" alt="la photo du logo GBAF">

			<div id="user-info">
            	<p>
             		Bonjour <?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?> !<br />
         		</p>
                 <a href="?ctrl=deconnection">DECONNEXION</a>
       		</div>
		</header>
        
        <div id="container" class="app">
            <h1><?php echo $_data['title']?></h1>

            <?php include("pages/$_page.php")?>
        </div>
    </body>
</html>