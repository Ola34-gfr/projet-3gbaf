<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8">
            <link rel="stylesheet" type="text/css" media="screen" href="accueil.css"/>

            <title>Le Groupement Banque Assurance Français <(GBAF)</title>
        </head>


        <body>

            <header>
                <img src="photogbaf-ConvertImage.png" alt="la photo du logo GBAF">

                <div id="user-info">
                    <div>
                        Bonjour <?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?> !<br />
                </div>   

                <div id="deconect">
                <a href="?ctrl=deconnection">DECONNEXION</a>
                </div>
            </header>


            <div id="conteneur">
                <section>
                    <h1>Bienvenue au GBAF</h1>

            
                    <p id="bordParagraphe">Le Groupement Banque Assurance Français (GBAF) souhaite proposer aux salariés des grands groupes
                français un point d’entrée unique, répertoriant un grand nombre d’informations
                sur les partenaires et acteurs du groupe ainsi que sur les produits et services
                bancaires et financiers.
                Chaque salarié pourra ainsi poster un commentaire et donner son avis</p>
                </section>


                <section>
                    <div id="cadre">  
                        <div id="forma">
                            <h3>
                                <img src="formation_co-mini-ConvertImage.png" class="imageflottante" alt="logo formation et co" id="logo">
                                <p>Formation&co est une association française présente sur tout le territoire...</p>
                                <a href="formnco.php?acteur=formation&amp;co"></a>
                            </h3>
                            <input type="submit" id='submit' value='lire la suite' >
                        </div>
                

                        <div id="protect">
                            <h3>
                                <img src="protectpeople-mini-ConvertImage.png" class="imageflottante" alt="logo de protect people" id="logo">
                                <p>Chez Protectpeople, chacun cotise selon ses moyens et reçoit selon ses besoins...</p>
                                <a href="protectpeo.php?acteur=protectpeople"></a>
                            </h3>
                            <input type="submit" id='submit' value='lire la suite' >
                        </div>
                

                        <div id="dsa">
                            <h3>
                                <img src="Dsa_france-mini-ConvertImage.png" class="imageflottante" alt="logo de DSA france" id="logo"> 
                                <p>Dsa France accélère la croissance du territoire et s’engage avec les collectivités territoriales...</p>
                                <a href="Dsa_france.php?acteur=dsa_france"></a>
                            </h3>
                            <input type="submit" id='submit' value='lire la suite' >
                        </div>

                        <div id="cde">
                            <h3>
                                <img src="CDE-mini-ConvertImage.png" class="imageflottante" alt="logo de CDE" id="logo">
                                <p>La CDE (Chambre Des Entrepreneurs) accompagne les entreprises dans leurs démarches de formation...</p>
                                <a href="cde.php?acteur=cde"></a>
                            </h3>

                            <input type="submit" id='submit' value='lire la suite' href="cde.php?acteur=cde" >
                        </div>
                    </div>
                </section>


                <footer id="pied_de_page">
                    <p>| Mentions légales | Contact |</p>
                </footer>
            </div>
        </body>
    </html>
